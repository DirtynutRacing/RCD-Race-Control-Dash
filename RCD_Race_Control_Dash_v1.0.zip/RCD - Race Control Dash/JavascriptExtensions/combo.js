/*
 * RCD - Race Control Dash - combo.js
 * Copyright (c) 2026 DIRTYNUT. All rights reserved.
 *
 * NOT open source. Free for personal, non-commercial use on your own rig only.
 * You may NOT copy, re-upload, redistribute, sell or charge for this file or
 * the dashboards, publish modified or derived versions, or use them to make a
 * competing dashboard. Do not remove this notice.
 * Full terms: LICENSE.txt in the dashboard folder.
 *
 * Provided "as is", without warranty of any kind.
 */

// Car, race, fuel, tyre and flag data for RCD - Race Control Dash.
// Timing, delta, sectors, spotter and inputs live in nano.js.
// Anything a sim doesn't send shows "--".

var CAR_DASH = '--';

function car_p(name) {
    var v = $prop(NANO_P + name);
    return (v === undefined) ? null : v;
}

function car_n(name) {
    return in_num(car_p(name));
}

function car_isIr() {
    var g = $prop('DataCorePlugin.CurrentGame');
    return typeof g === 'string' && g.toLowerCase().indexOf('iracing') >= 0;
}

// ------------------------------------------------------------------ gear, speed, rpm
function car_gear() {
    var g = car_p('Gear');
    if (g === null || g === '') return 'N';
    g = String(g);
    if (g === '0') return 'N';
    if (g === '-1') return 'R';
    return g.toUpperCase();
}

function car_speed() {
    var v = car_n('SpeedLocal');
    if (v === null) v = car_n('SpeedKmh');
    return v === null ? '0' : String(Math.round(Math.max(0, v)));
}

// SimHub shows speed in the unit picked in its settings; work out which one that is
function car_speedUnit() {
    var u = $prop('DataCorePlugin.GameData.SpeedLocalUnit');
    if (typeof u !== 'string' || !u) u = car_p('SpeedLocalUnit');
    if (typeof u === 'string' && u) {
        root['carSpdU'] = u.toLowerCase().indexOf('mph') >= 0 ? 'MPH' : 'KM/H';
        return root['carSpdU'];
    }
    var loc = car_n('SpeedLocal'), kmh = car_n('SpeedKmh');
    if (loc !== null && kmh !== null && kmh > 20) {
        root['carSpdU'] = Math.abs(loc - kmh * 0.621371) < Math.abs(loc - kmh) ? 'MPH' : 'KM/H';
    }
    return root['carSpdU'] || 'KM/H';
}

// Rev bar range taken from the game, so it matches the car:
//  iRacing : the car's own shift-light points (first light, shift, blink)
//  others  : the game's max RPM (rev limiter), shift point just below it
// lo = where the bar starts, shift = where it turns blue, hi = full bar
function car_rpmRange() {
    var key = Date.now();
    if (root['carRR'] && root['carRRt'] === key) return root['carRR'];
    var r = null;
    if (car_isIr()) {
        var SD = 'SessionData.DriverInfo.DriverCarSL';
        var first = in_first(['DataCorePlugin.GameRawData.' + SD + 'FirstRPM', 'GameRawData.' + SD + 'FirstRPM']);
        var shift = in_first(['DataCorePlugin.GameRawData.' + SD + 'ShiftRPM', 'GameRawData.' + SD + 'ShiftRPM']);
        var last = in_first(['DataCorePlugin.GameRawData.' + SD + 'LastRPM', 'GameRawData.' + SD + 'LastRPM']);
        var blink = in_first(['DataCorePlugin.GameRawData.' + SD + 'BlinkRPM', 'GameRawData.' + SD + 'BlinkRPM']);
        var top = blink > 0 ? blink : last;
        if (first > 0 && top > first) {
            var sh = shift > first ? shift : (last > first ? last : top);
            r = { lo: first, shift: Math.min(sh, top), hi: top };
        }
    }
    if (!r) {
        var max = car_n('MaxRpm');
        if (max > 1000) {
            var red = in_first([NANO_P + 'CarSettings_RedLineRPM', NANO_P + 'CarSettings_CurrentGearRedLineRPM']);
            var shiftAt = (red > max * 0.6 && red <= max) ? red : max * 0.97;
            r = { lo: max * 0.55, shift: shiftAt, hi: max };
        }
    }
    root['carRR'] = r;
    root['carRRt'] = key;
    return r;
}

function car_rpm() {
    var v = car_n('Rpms');
    return v === null ? 0 : Math.max(0, v);
}

function car_rpmText() {
    var v = car_n('Rpms');
    return v === null ? '-- RPM' : Math.round(Math.max(0, v)) + ' RPM';
}

// 0..1 bar fill
function car_rpmPct() {
    var r = car_rpmRange();
    if (r) return Math.max(0, Math.min(1, (car_rpm() - r.lo) / (r.hi - r.lo)));
    var p = car_n('CarSettings_CurrentDisplayedRPMPercent');
    return p === null ? 0 : Math.max(0, Math.min(1, p / 100));
}

function car_shiftNow() {
    var r = car_rpmRange();
    if (r) return car_rpm() >= r.shift;
    return car_rpmPct() >= 0.95;
}

// segment colour: green / yellow / red towards the shift point, all blue once you should shift
function car_rpmSegCol(i, n) {
    if (car_shiftNow()) return '#FF2F7BFF';
    var r = car_rpmRange();
    var segPct = (i + 1) / n;
    var shiftPct = r ? (r.shift - r.lo) / (r.hi - r.lo) : 0.95;
    var f = shiftPct > 0 ? segPct / shiftPct : segPct;
    if (f < 0.6) return '#FF2EE66B';
    if (f < 0.85) return '#FFFFD23F';
    return '#FFFF2D55';
}

function car_limiter() {
    return nano_flag('PitLimiterOn');
}

// ------------------------------------------------------------------ race
function car_posText() {
    var p = car_n('Position');
    return p > 0 ? 'P' + Math.round(p) : 'P-';
}

function car_carsText() {
    var n = car_n('OpponentsCount');
    if (!(n > 0)) n = in_first(['DataCorePlugin.GameData.NewData.PlayerCount']);
    return n > 0 ? '/ ' + Math.round(n) : '';
}

function car_fmtGap(v, sign) {
    if (v === null || !isFinite(v) || v === 0) return '-.---';
    v = Math.abs(v);
    if (v >= 100) return sign + Math.round(v);
    return sign + v.toFixed(v >= 10 ? 1 : 3);
}

function car_gapAhead() {
    return car_fmtGap(in_first(['PersistantTrackerPlugin.DriverAhead_00_Gap']), '-');
}

function car_gapBehind() {
    return car_fmtGap(in_first(['PersistantTrackerPlugin.DriverBehind_00_Gap']), '+');
}

function car_hasInc() {
    return car_isIr();
}

function car_incText() {
    if (!car_isIr()) return CAR_DASH;
    var v = in_first(['DataCorePlugin.GameRawData.Telemetry.PlayerCarMyIncidentCount',
                      'GameRawData.Telemetry.PlayerCarMyIncidentCount']);
    return v === null ? CAR_DASH : Math.round(v) + 'x';
}

function car_fmtClock(s) {
    s = Math.max(0, Math.floor(s));
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
    var mm = (h > 0 && m < 10 ? '0' : '') + m, rr = (r < 10 ? '0' : '') + r;
    return h > 0 ? h + ':' + mm + ':' + rr : mm + ':' + rr;
}

// laps still to drive including the current one, or null if unknown
function car_lapsToGo() {
    var tot = car_n('TotalLaps'), cur = car_n('CurrentLap');
    if (tot > 0 && cur !== null) {
        var pct = in_num($prop(NANO_P + 'TrackPositionPercent'));
        return Math.max(0, tot - cur + 1 - (pct > 0 && pct < 1 ? pct : 0));
    }
    var left = nano_secs(car_p('SessionTimeLeft'));
    var lap = nano_refSecs();
    if (!(lap > 0)) lap = nano_secs(car_p('LastLapTime'));
    if (left > 0 && lap > 0) return Math.ceil(left / lap) + 0;
    return null;
}

function car_sessionLeft() {
    var left = nano_secs(car_p('SessionTimeLeft'));
    if (left > 0) return car_fmtClock(left) + ' LEFT';
    var tot = car_n('TotalLaps'), cur = car_n('CurrentLap');
    if (tot > 0 && cur !== null) {
        var n = Math.max(0, tot - cur);
        return n === 0 ? 'LAST LAP' : n + (n === 1 ? ' LAP LEFT' : ' LAPS LEFT');
    }
    return '';
}

// sum of your session-best sectors (works for iRacing multi-sector too)
function car_optimalText() {
    var m = ms_model(), t = 0;
    for (var i = 0; i < m.N; i++) {
        if (!(m.sbest[i] > 0)) return '-:--.---';
        t += m.sbest[i];
    }
    return nano_fmtLap(t, '-:--.---');
}

// ------------------------------------------------------------------ flags
function car_flag() {
    if (nano_flag('Flag_Black')) return 'black';
    if (nano_flag('Flag_Yellow')) return 'yellow';
    if (nano_flag('Flag_Blue')) return 'blue';
    if (nano_flag('Flag_White')) return 'white';
    if (nano_flag('Flag_Checkered')) return 'checkered';
    return '';
}

function car_flagCol() {
    var f = car_flag();
    if (f === 'yellow') return '#FFFFD23F';
    if (f === 'blue') return '#FF2F7BFF';
    if (f === 'black') return '#FFFF6A00';
    return '#FFFFFFFF';
}

// ------------------------------------------------------------------ aids / bias
function car_aidBg(prop, off) { return in_aid(prop) ? IN_AMBER : off; }
function car_aidFg(prop, col) { return in_aid(prop) ? '#FF000000' : col; }

function car_level(paths) {
    var v = in_first(paths);
    if (v === null || v < 0) return CAR_DASH;
    return String(Math.round(v));
}

function car_absText() {
    return car_level([NANO_P + 'ABSLevel', 'DataCorePlugin.GameRawData.Telemetry.dcABS',
                      'GameRawData.Telemetry.dcABS']);
}

function car_tcText() {
    return car_level([NANO_P + 'TCLevel', 'DataCorePlugin.GameRawData.Telemetry.dcTractionControl',
                      'GameRawData.Telemetry.dcTractionControl']);
}

function car_bbText() {
    var v = in_first([NANO_P + 'BrakeBias', 'DataCorePlugin.GameRawData.Telemetry.dcBrakeBias',
                      'GameRawData.Telemetry.dcBrakeBias']);
    if (v === null || !(v > 0)) return CAR_DASH;
    if (v <= 1) v *= 100;
    return v.toFixed(1) + '%';
}

// ------------------------------------------------------------------ fuel
function car_fuelGal() {
    var u = car_p('FuelUnit');
    return typeof u === 'string' && u.toLowerCase().indexOf('gal') >= 0;
}

function car_fmtFuel(v, plus, dp) {
    if (v === null || v === undefined || !isFinite(v)) return CAR_DASH;
    if (dp === undefined) dp = v >= 100 ? 0 : (car_fuelGal() ? 2 : 1);
    return (plus && v > 0 ? '+' : '') + v.toFixed(dp) + (car_fuelGal() ? ' gal' : ' L');
}

// own per-lap tracking, used when SimHub's computed values aren't there
function car_fuelTick() {
    var key = Date.now();
    if (root['carFT'] === key) return;
    root['carFT'] = key;
    var lap = car_n('CurrentLap'), fuel = car_n('Fuel');
    if (lap === null || fuel === null) return;
    if (root['carFLap'] !== lap) {
        var startF = root['carFStart'];
        if (root['carFLap'] !== undefined && lap === root['carFLap'] + 1 && startF > fuel && !root['carFPit']) {
            root['carFUsed'] = startF - fuel;
            var h = root['carFHist'] || [];
            h.push(startF - fuel);
            if (h.length > 5) h.shift();
            root['carFHist'] = h;
        }
        root['carFLap'] = lap;
        root['carFStart'] = fuel;
        root['carFPit'] = nano_inPit();
    } else if (nano_inPit()) {
        root['carFPit'] = true;
    }
}

function car_perLap() {
    car_fuelTick();
    var v = in_first(['DataCorePlugin.Computed.Fuel_LitersPerLap']);
    if (v !== null && v > 0) return v;
    var h = root['carFHist'];
    if (!h || !h.length) return null;
    var s = 0;
    for (var i = 0; i < h.length; i++) s += h[i];
    return s / h.length;
}

function car_fuelText() { return car_fmtFuel(car_n('Fuel'), false); }
function car_perLapText() { return car_fmtFuel(car_perLap(), false, 2); }

function car_usedText() {
    car_fuelTick();
    var v = in_first(['DataCorePlugin.Computed.Fuel_LastLapConsumption']);
    if (v === null || !(v > 0)) v = root['carFUsed'];
    return car_fmtFuel(v > 0 ? v : null, false, 2);
}

function car_fuelLaps() {
    var v = in_first(['DataCorePlugin.Computed.Fuel_RemainingLaps']);
    if (v !== null && v >= 0) return v;
    var pl = car_perLap(), f = car_n('Fuel');
    return (pl > 0 && f !== null) ? f / pl : null;
}

function car_fuelLapsText() {
    var v = car_fuelLaps();
    return v === null ? CAR_DASH : (v >= 100 ? '99+' : v.toFixed(1));
}

function car_needText() {
    var pl = car_perLap(), n = car_lapsToGo();
    return (pl > 0 && n !== null) ? car_fmtFuel(pl * n, false) : CAR_DASH;
}

function car_addText() {
    var pl = car_perLap(), n = car_lapsToGo(), f = car_n('Fuel');
    if (!(pl > 0) || n === null || f === null) return CAR_DASH;
    return car_fmtFuel(Math.max(0, pl * n - f), true);
}

function car_fuelPct() {
    var p = car_n('FuelPercent');
    if (p !== null) return Math.max(0, Math.min(1, p / 100));
    var f = car_n('Fuel'), m = car_n('MaxFuel');
    return (f !== null && m > 0) ? Math.max(0, Math.min(1, f / m)) : 0;
}

// Low fuel: SimHub's low-fuel alert (car settings / Telemetry Tester), under 2 laps of fuel,
// or under 10% in the tank while there's no fuel-per-lap figure yet.
function car_lowFuel() {
    if (nano_flag('CarSettings_FuelAlertActive')) return true;
    var t = $prop('TelemetryTesterPlugin.LowFuelAlert');
    if (t === true || t === 1 || t === 'True' || t === 'true') return true;
    var l = car_fuelLaps();
    if (l !== null) return l < 2;
    var f = car_n('Fuel');
    if (f !== null && f <= 0) return false;
    var pct = car_fuelPct();
    return pct > 0 && pct < 0.1;
}

function car_fuelCol() {
    var l = car_fuelLaps();
    if (car_lowFuel()) return '#FFFF2D55';
    if (l !== null && l < 4) return '#FFFFD23F';
    return '#FF2EE66B';
}

// ------------------------------------------------------------------ tyres, brakes, engine
var CAR_CORNER = ['FrontLeft', 'FrontRight', 'RearLeft', 'RearRight'];

function car_tempF() {
    var u = car_p('TemperatureUnit');
    return typeof u === 'string' && u.toLowerCase().indexOf('f') === 0;
}

// thresholds are in C; convert when SimHub shows F
function car_tC(v) { return car_tempF() ? (v - 32) * 5 / 9 : v; }

function car_zone(i, k) {        // k: 0 inner, 1 middle, 2 outer
    var c = CAR_CORNER[i];
    var v = car_n('TyreTemperature' + c + ['Inner', 'Middle', 'Outer'][k]);
    return v !== null && v > 0 ? v : car_n('TyreTemperature' + c);
}

function car_tyreAvg(i) {
    var s = 0, n = 0;
    for (var k = 0; k < 3; k++) {
        var v = car_zone(i, k);
        if (v !== null && v > 0) { s += v; n++; }
    }
    return n ? s / n : null;
}

function car_tyreColFor(v) {
    if (v === null || !(v > 0)) return '#FF5F7A8A';
    var c = car_tC(v);
    if (c < 70) return '#FF4FC3F7';
    if (c < 95) return '#FF2EE66B';
    if (c < 105) return '#FFFFD23F';
    return '#FFFF2D55';
}

function car_tyreTemp(i) {
    var v = car_tyreAvg(i);
    return v === null ? '--°' : Math.round(v) + '°';
}

function car_tyreCol(i) { return car_tyreColFor(car_tyreAvg(i)); }

// zone strip left -> right as seen from behind the car (inner edge towards the middle)
function car_tyreZoneCol(i, k) {
    var right = (i === 1 || i === 3);
    var zone = right ? k : 2 - k;
    return car_tyreColFor(car_zone(i, zone));
}

function car_tyreZones(i) {
    var right = (i === 1 || i === 3), out = [];
    for (var k = 0; k < 3; k++) {
        var v = car_zone(i, right ? k : 2 - k);
        out.push(v === null ? '--' : Math.round(v));
    }
    return out.join(' ');
}

function car_tyrePress(i) {
    var v = car_n('TyrePressure' + CAR_CORNER[i]);
    if (v === null || !(v > 0)) return '-- psi';
    if (v > 60) return Math.round(v) + ' kPa';
    if (v < 8) return v.toFixed(2) + ' bar';
    return v.toFixed(1) + ' psi';
}

// tyre life left, 0..100 (null if the sim doesn't send it)
function car_tyreWearRaw(i) {
    var v = car_n('TyreWear' + CAR_CORNER[i]);
    if (v === null) return null;
    if (v <= 1.0001) v *= 100;
    return Math.round(Math.max(0, Math.min(100, v)));
}

function car_tyreWear(i) {
    var v = car_tyreWearRaw(i);
    return v === null ? 0 : v;
}

function car_brakeTemp(i) {
    return car_n('BrakeTemperature' + CAR_CORNER[i]);
}

function car_brakeCol(i) {
    var v = car_brakeTemp(i);
    if (v === null || !(v > 0)) return '#FF14202B';
    var c = car_tC(v);
    if (c < 200) return '#FF4FC3F7';
    if (c < 650) return '#FF2EE66B';
    if (c < 800) return '#FFFFD23F';
    return '#FFFF2D55';
}

function car_tyreFoot(i) {
    var b = car_brakeTemp(i);
    var w = car_tyreWearRaw(i);
    return 'TYRE ' + (w === null ? '--' : w + '%') + '   BRAKE ' + (b !== null && b > 0 ? Math.round(b) + '°' : '--');
}

function car_tempText(name) {
    var v = car_n(name);
    return v === null || !(v > 0) ? CAR_DASH : Math.round(v) + '°';
}

function car_waterText() { return car_tempText('WaterTemperature'); }
function car_oilText() { return car_tempText('OilTemperature'); }
